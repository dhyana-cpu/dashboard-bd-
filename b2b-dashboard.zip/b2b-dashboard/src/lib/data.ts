export type MailRecord = {
  date: string;
  delivered: number;
  opened: number;
  clicked: number;
  responded: number;
  bounced: number;
};

export type SalesRecord = {
  date: string;
  refNo: string;
  orderType: string;
  poc: string;
  clientName: string;
  revenue: number;
};

export type AdsRecord = {
  date: string;
  clientName: string;
  industry: string;
  inbounds: number;
  b2b: number;
  ccbd: number;
  poc: string;
  orderValue: string;
  conversion: string;
  leadType: string;
};

export type InMailRecord = {
  srNo: number;
  industry: string;
  companyName: string;
  role: string;
  poc: string;
  linkedin: string;
};

export type EmailByIndustry = {
  industry: string;
  delivered: number;
  opened: number;
  clicked: number;
  responded: number;
  bounced: number;
};

export const mailData: MailRecord[] = [
  { date: "2026-04-08", delivered: 994, opened: 177, clicked: 26, responded: 51, bounced: 0 },
  { date: "2026-04-09", delivered: 811, opened: 150, clicked: 9,  responded: 5,  bounced: 0 },
  { date: "2026-04-10", delivered: 1062,opened: 182, clicked: 17, responded: 2,  bounced: 0 },
  { date: "2026-04-11", delivered: 0,   opened: 27,  clicked: 27, responded: 0,  bounced: 0 },
  { date: "2026-04-12", delivered: 0,   opened: 2,   clicked: 0,  responded: 0,  bounced: 0 },
  { date: "2026-04-13", delivered: 387, opened: 87,  clicked: 9,  responded: 2,  bounced: 0 },
];

export const emailByIndustry: EmailByIndustry[] = [
  { industry: "Corporates",          delivered: 812,  opened: 153, clicked: 15, responded: 4,  bounced: 9  },
  { industry: "IT (8 Apr)",          delivered: 767,  opened: 173, clicked: 16, responded: 4,  bounced: 8  },
  { industry: "Facility Mgmt (7 Apr)",delivered:1172, opened: 234, clicked: 52, responded: 51, bounced: 41 },
  { industry: "IT (9 Apr)",          delivered: 503,  opened: 65,  clicked: 5,  responded: 1,  bounced: 16 },
];

export const salesData: SalesRecord[] = [
  { date: "2026-04-01", refNo: "Apr26-001", orderType: "Inst Order", poc: "Siya",    clientName: "Floraza",                  revenue: 7890.9  },
  { date: "2026-04-02", refNo: "Apr26-024", orderType: "Inst Order", poc: "Manjari", clientName: "Gerson Lehrman Group",      revenue: 16830   },
  { date: "2026-04-02", refNo: "Apr26-044", orderType: "Inst Order", poc: "Dhyana",  clientName: "Qteam Solution Services",   revenue: 20500   },
  { date: "2026-04-04", refNo: "Apr26-050", orderType: "Inst Order", poc: "Siya",    clientName: "Capgemini",                 revenue: 5600    },
  { date: "2026-04-06", refNo: "Apr26-060", orderType: "Inst Order", poc: "Manjari", clientName: "Deloitte India",            revenue: 42376   },
  { date: "2026-04-06", refNo: "Apr26-061", orderType: "Inst Order", poc: "Dhyana",  clientName: "KPMG India",                revenue: 43000   },
  { date: "2026-04-07", refNo: "Apr26-070", orderType: "Inst Order", poc: "Siya",    clientName: "Accenture",                 revenue: 51200   },
  { date: "2026-04-07", refNo: "Apr26-071", orderType: "Inst Order", poc: "Manjari", clientName: "EY India",                  revenue: 38946   },
  { date: "2026-04-07", refNo: "Apr26-072", orderType: "Inst Order", poc: "Dhyana",  clientName: "PwC India",                 revenue: 42000   },
  { date: "2026-04-07", refNo: "Apr26-073", orderType: "Inst Order", poc: "Siya",    clientName: "Cognizant",                 revenue: 42000   },
  { date: "2026-04-08", refNo: "Apr26-080", orderType: "Inst Order", poc: "Manjari", clientName: "IBM India",                 revenue: 21160   },
  { date: "2026-04-13", refNo: "Apr26-090", orderType: "Inst Order", poc: "Dhyana",  clientName: "Infosys BPM",               revenue: 42180   },
  { date: "2026-04-13", refNo: "Apr26-091", orderType: "Inst Order", poc: "Siya",    clientName: "Wipro Ltd",                 revenue: 42500.7 },
];

export const adsData: AdsRecord[] = [
  { date: "2026-03-31", clientName: "Vijay Chaudhary",  industry: "",                           inbounds: 6, b2b: 4, ccbd: 1, poc: "Manjari", orderValue: "_",   conversion: "No",  leadType: "Cold" },
  { date: "2026-03-31", clientName: "Rachael",          industry: "",                           inbounds: 0, b2b: 0, ccbd: 0, poc: "Siya",    orderValue: "",    conversion: "",    leadType: "Cold" },
  { date: "2026-03-31", clientName: "Gaunisha Gaanavi", industry: "Striim Engineering",         inbounds: 0, b2b: 0, ccbd: 0, poc: "Manjari", orderValue: "",    conversion: "No",  leadType: "Cold" },
  { date: "2026-03-31", clientName: "Rajesh Taneja",    industry: "",                           inbounds: 0, b2b: 0, ccbd: 0, poc: "Dhyana",  orderValue: "",    conversion: "No",  leadType: "Cold" },
  { date: "2026-03-31", clientName: "Priya Mehta",      industry: "Tech Solutions",             inbounds: 0, b2b: 0, ccbd: 0, poc: "Siya",    orderValue: "",    conversion: "No",  leadType: "Warm" },
  { date: "2026-04-01", clientName: "Arvind Shah",      industry: "Manufacturing",              inbounds: 3, b2b: 1, ccbd: 0, poc: "Manjari", orderValue: "",    conversion: "No",  leadType: "Cold" },
  { date: "2026-04-02", clientName: "Sunita Rao",       industry: "FMCG",                       inbounds: 2, b2b: 1, ccbd: 1, poc: "Dhyana",  orderValue: "45000", conversion: "Yes", leadType: "Warm" },
  { date: "2026-04-06", clientName: "Rakesh Gupta",     industry: "IT Services",                inbounds: 4, b2b: 2, ccbd: 1, poc: "Siya",    orderValue: "",    conversion: "No",  leadType: "Cold" },
  { date: "2026-04-06", clientName: "Meena Iyer",       industry: "Pharma",                     inbounds: 0, b2b: 1, ccbd: 0, poc: "Manjari", orderValue: "",    conversion: "No",  leadType: "Cold" },
  { date: "2026-04-06", clientName: "Deepak Nair",      industry: "Real Estate",                inbounds: 5, b2b: 2, ccbd: 1, poc: "Dhyana",  orderValue: "30000", conversion: "No",  leadType: "Warm" },
  { date: "2026-04-06", clientName: "Ananya Krishnan",  industry: "Education",                  inbounds: 0, b2b: 0, ccbd: 0, poc: "Siya",    orderValue: "",    conversion: "No",  leadType: "Cold" },
  { date: "2026-04-07", clientName: "Sanjay Patel",     industry: "Logistics",                  inbounds: 3, b2b: 0, ccbd: 0, poc: "Manjari", orderValue: "",    conversion: "No",  leadType: "Cold" },
  { date: "2026-04-07", clientName: "Kavitha Reddy",    industry: "Healthcare",                 inbounds: 2, b2b: 0, ccbd: 0, poc: "Dhyana",  orderValue: "",    conversion: "No",  leadType: "Warm" },
  { date: "2026-04-08", clientName: "Nitin Joshi",      industry: "Banking",                    inbounds: 5, b2b: 1, ccbd: 1, poc: "Siya",    orderValue: "60000", conversion: "Yes", leadType: "Warm" },
  { date: "2026-04-08", clientName: "Pooja Sharma",     industry: "Insurance",                  inbounds: 0, b2b: 0, ccbd: 0, poc: "Manjari", orderValue: "",    conversion: "No",  leadType: "Cold" },
  { date: "2026-04-08", clientName: "Alok Verma",       industry: "Retail",                     inbounds: 2, b2b: 0, ccbd: 0, poc: "Dhyana",  orderValue: "",    conversion: "No",  leadType: "Cold" },
  { date: "2026-04-09", clientName: "Shruti Jain",      industry: "Consulting",                 inbounds: 1, b2b: 0, ccbd: 0, poc: "Siya",    orderValue: "",    conversion: "No",  leadType: "Cold" },
];

export const inMailData: InMailRecord[] = [
  { srNo: 1,  industry: "FM", companyName: "CBRE South Asia",                    role: "Assistant Manager",              poc: "Rajesh K Nair",    linkedin: "https://www.linkedin.com/in/rajesh-k-nair-32934a79" },
  { srNo: 2,  industry: "FM", companyName: "Quess Corp",                         role: "General Manager Procurement",    poc: "Shiv Kumara",      linkedin: "https://www.linkedin.com/in/shivakumara-m-procurement-specialist-pan-india-apac-5a734b32" },
  { srNo: 3,  industry: "FM", companyName: "Supreme Facility Management Ltd",    role: "Group Director and CEO",         poc: "Dr. Amol Shingate",linkedin: "https://www.linkedin.com/in/dr-amol-shingate-1b73b411b" },
  { srNo: 4,  industry: "FM", companyName: "BVG India Ltd",                      role: "National Sales Head",            poc: "Anand Sawant",     linkedin: "https://www.linkedin.com/in/anand-sawant" },
  { srNo: 5,  industry: "FM", companyName: "NoBrokerHood",                       role: "Head of Business",               poc: "Payal Parikh",     linkedin: "https://www.linkedin.com/in/payal-parikh" },
  { srNo: 6,  industry: "FM", companyName: "Jio Platforms",                      role: "Procurement Manager",            poc: "Ravi Kumar",       linkedin: "https://www.linkedin.com/in/ravi-kumar" },
  { srNo: 7,  industry: "IT", companyName: "Infosys BPM",                        role: "HR Manager",                     poc: "Sneha Iyer",       linkedin: "https://www.linkedin.com/in/sneha-iyer" },
  { srNo: 8,  industry: "IT", companyName: "Wipro",                              role: "Admin Head",                     poc: "Arjun Menon",      linkedin: "https://www.linkedin.com/in/arjun-menon" },
  { srNo: 9,  industry: "IT", companyName: "HCL Technologies",                   role: "Facility Head",                  poc: "Priya Sharma",     linkedin: "https://www.linkedin.com/in/priya-sharma" },
  { srNo: 10, industry: "IT", companyName: "TCS",                                role: "Procurement Lead",               poc: "Vikram Nair",      linkedin: "https://www.linkedin.com/in/vikram-nair" },
  { srNo: 11, industry: "FM", companyName: "Sodexo India",                       role: "Business Development Manager",   poc: "Nisha Kapoor",     linkedin: "https://www.linkedin.com/in/nisha-kapoor" },
];
