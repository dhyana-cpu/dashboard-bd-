import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "B2B Activity Dashboard",
  description: "Track daily mails, sales, ads, events and inmails",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
