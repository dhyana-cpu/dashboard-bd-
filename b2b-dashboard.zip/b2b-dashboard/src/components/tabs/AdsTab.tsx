"use client";
import { useMemo } from "react";
import { Bar } from "react-chartjs-2";
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Tooltip, Legend } from "chart.js";
import { MetricCard, MetricGrid, SectionTitle, Card, TableWrap, Table, Th, Td, Badge } from "@/components/UI";
import type { AdsRecord } from "@/lib/data";
import styles from "./Tabs.module.css";

ChartJS.register(CategoryScale, LinearScale, BarElement, Tooltip, Legend);
const pct = (a: number, b: number) => (b > 0 ? Math.round((a / b) * 100) + "%" : "0%");

export default function AdsTab({ data }: { data: AdsRecord[] }) {
  const totInbounds = data.reduce((s, d) => s + d.inbounds, 0);
  const totB2B      = data.reduce((s, d) => s + d.b2b, 0);
  const totWarm     = data.filter(d => d.leadType === "Warm").length;
  const totConv     = data.filter(d => d.conversion.toLowerCase() === "yes").length;

  const chartData = useMemo(() => {
    const byDate: Record<string, { inbounds: number; b2b: number }> = {};
    data.forEach(d => {
      if (!byDate[d.date]) byDate[d.date] = { inbounds: 0, b2b: 0 };
      byDate[d.date].inbounds += d.inbounds;
      byDate[d.date].b2b += d.b2b;
    });
    const dates = Object.keys(byDate).sort();
    return {
      labels: dates.map(d => d.slice(5)),
      datasets: [
        { label: "Inbounds", data: dates.map(d => byDate[d].inbounds), backgroundColor: "#6c6af6", borderRadius: 4 },
        { label: "B2B",      data: dates.map(d => byDate[d].b2b),      backgroundColor: "#36c98e", borderRadius: 4 },
      ],
    };
  }, [data]);

  const opts = {
    responsive: true, maintainAspectRatio: false,
    plugins: { legend: { display: false } },
    scales: {
      x: { ticks: { color: "#4f4e58", font: { size: 11 } }, grid: { display: false } },
      y: { ticks: { color: "#4f4e58", font: { size: 11 } }, grid: { color: "rgba(255,255,255,0.04)" } },
    },
  };

  return (
    <div>
      <MetricGrid>
        <MetricCard label="Total Inbounds" value={totInbounds} accent="accent" />
        <MetricCard label="B2B Leads"      value={totB2B} sub={`${pct(totB2B, totInbounds)} of inbounds`} accent="green" />
        <MetricCard label="Warm Leads"     value={totWarm} accent="amber" />
        <MetricCard label="Conversions"    value={totConv} sub={`${pct(totConv, data.length)} conv. rate`} accent="blue" />
      </MetricGrid>

      <SectionTitle>Daily inbounds vs B2B leads</SectionTitle>
      <Card>
        <div className={styles.legendRow} style={{ marginBottom: 16 }}>
          <span className={styles.legendItem}><span className={styles.dot} style={{ background: "#6c6af6" }} />Inbounds</span>
          <span className={styles.legendItem}><span className={styles.dot} style={{ background: "#36c98e" }} />B2B leads</span>
        </div>
        <div className={styles.chartWrap}>
          <Bar data={chartData} options={opts} aria-label="Daily inbounds chart" />
        </div>
      </Card>

      <SectionTitle>All ad leads</SectionTitle>
      <TableWrap>
        <Table>
          <thead>
            <tr>
              <Th>Date</Th>
              <Th>Client</Th>
              <Th>Industry</Th>
              <Th>POC</Th>
              <Th right>Inbounds</Th>
              <Th right>B2B</Th>
              <Th>Lead type</Th>
              <Th>Converted</Th>
            </tr>
          </thead>
          <tbody>
            {data.map((r, i) => (
              <tr key={i}>
                <Td mono muted>{r.date}</Td>
                <Td>{r.clientName}</Td>
                <Td muted>{r.industry || "—"}</Td>
                <Td><Badge variant="purple">{r.poc}</Badge></Td>
                <Td right mono>{r.inbounds || "—"}</Td>
                <Td right mono>{r.b2b || "—"}</Td>
                <Td>
                  <Badge variant={r.leadType === "Warm" ? "amber" : "muted"}>{r.leadType}</Badge>
                </Td>
                <Td>
                  {r.conversion ? (
                    <Badge variant={r.conversion.toLowerCase() === "yes" ? "green" : "coral"}>
                      {r.conversion}
                    </Badge>
                  ) : <span style={{ color: "var(--text-faint)" }}>—</span>}
                </Td>
              </tr>
            ))}
          </tbody>
        </Table>
      </TableWrap>
    </div>
  );
}
