"use client";
import { useMemo } from "react";
import { Bar } from "react-chartjs-2";
import {
  Chart as ChartJS, CategoryScale, LinearScale,
  BarElement, Tooltip, Legend
} from "chart.js";
import { MetricCard, MetricGrid, SectionTitle, Card, TableWrap, Table, Th, Td, Badge } from "@/components/UI";
import type { MailRecord, SalesRecord, AdsRecord, InMailRecord, EmailByIndustry } from "@/lib/data";
import styles from "./Tabs.module.css";

ChartJS.register(CategoryScale, LinearScale, BarElement, Tooltip, Legend);

const fmtINR = (n: number) => "₹" + Math.round(n).toLocaleString("en-IN");
const pct = (a: number, b: number) => (b > 0 ? Math.round((a / b) * 100) + "%" : "0%");

const CHART_OPTS = {
  responsive: true, maintainAspectRatio: false,
  plugins: { legend: { display: false }, tooltip: { callbacks: {} } },
  scales: {
    x: { ticks: { color: "#4f4e58", font: { size: 11 } }, grid: { display: false } },
    y: { ticks: { color: "#4f4e58", font: { size: 11 } }, grid: { color: "rgba(255,255,255,0.04)" } },
  },
};

export default function OverviewTab({ mails, sales, ads, inmails, emailByIndustry }: {
  mails: MailRecord[];
  sales: SalesRecord[];
  ads: AdsRecord[];
  inmails: InMailRecord[];
  emailByIndustry: EmailByIndustry[];
}) {
  const totDel = mails.reduce((s, d) => s + d.delivered, 0);
  const totOpen = mails.reduce((s, d) => s + d.opened, 0);
  const totResp = mails.reduce((s, d) => s + d.responded, 0);
  const totRev = sales.reduce((s, d) => s + d.revenue, 0);
  const totOrders = sales.reduce((s, d) => s + 1, 0);
  const totLeads = ads.reduce((s, d) => s + d.inbounds, 0);
  const totB2B = ads.reduce((s, d) => s + d.b2b, 0);

  const mailChartData = useMemo(() => ({
    labels: mails.map(d => d.date.slice(5)),
    datasets: [
      { label: "Delivered", data: mails.map(d => d.delivered), backgroundColor: "#4fa3e8", borderRadius: 4 },
      { label: "Opened",    data: mails.map(d => d.opened),    backgroundColor: "#36c98e", borderRadius: 4 },
    ],
  }), [mails]);

  const salesChartData = useMemo(() => {
    const byDate = sales.reduce((acc, s) => {
      acc[s.date] = (acc[s.date] || 0) + s.revenue;
      return acc;
    }, {} as Record<string, number>);
    const dates = Object.keys(byDate).sort();
    return {
      labels: dates.map(d => d.slice(5)),
      datasets: [{ label: "Revenue", data: dates.map(d => byDate[d]), backgroundColor: "#6c6af6", borderRadius: 4 }],
    };
  }, [sales]);

  return (
    <div>
      <MetricGrid>
        <MetricCard label="Emails Delivered"  value={totDel.toLocaleString()} sub={`${pct(totOpen, totDel)} open rate`} accent="blue" />
        <MetricCard label="Responses"         value={totResp} sub={`${pct(totResp, totDel)} response rate`} accent="green" />
        <MetricCard label="Total Revenue"     value={fmtINR(totRev)} sub={`${totOrders} orders`} accent="accent" />
        <MetricCard label="Ad Inbounds"       value={totLeads} sub={`${totB2B} B2B leads`} accent="amber" />
        <MetricCard label="InMails Sent"      value={inmails.length} sub="LinkedIn outreach" accent="coral" />
      </MetricGrid>

      <div className={styles.twoCol}>
        <div>
          <SectionTitle>Mail activity</SectionTitle>
          <Card>
            <div className={styles.chartWrap}>
              <Bar data={mailChartData} options={CHART_OPTS} aria-label="Mail activity chart" />
            </div>
            <div className={styles.legendRow}>
              <span className={styles.legendItem}><span className={styles.dot} style={{ background: "#4fa3e8" }} />Delivered</span>
              <span className={styles.legendItem}><span className={styles.dot} style={{ background: "#36c98e" }} />Opened</span>
            </div>
          </Card>
        </div>
        <div>
          <SectionTitle>Daily revenue</SectionTitle>
          <Card>
            <div className={styles.chartWrap}>
              <Bar
                data={salesChartData}
                options={{
                  ...CHART_OPTS,
                  plugins: { ...CHART_OPTS.plugins, tooltip: { callbacks: { label: (v) => fmtINR(v.raw as number) } } },
                  scales: {
                    ...CHART_OPTS.scales,
                    y: { ...CHART_OPTS.scales.y, ticks: { ...CHART_OPTS.scales.y.ticks, callback: (v) => "₹" + Math.round(Number(v) / 1000) + "k" } },
                  },
                }}
                aria-label="Daily revenue chart"
              />
            </div>
          </Card>
        </div>
      </div>

      <SectionTitle>Mail performance by industry</SectionTitle>
      <TableWrap>
        <Table>
          <thead>
            <tr>
              <Th>Industry</Th>
              <Th right>Delivered</Th>
              <Th right>Opened</Th>
              <Th right>Clicked</Th>
              <Th right>Responded</Th>
              <Th right>Open rate</Th>
              <Th right>Bounced</Th>
            </tr>
          </thead>
          <tbody>
            {emailByIndustry.map(r => (
              <tr key={r.industry}>
                <Td>{r.industry}</Td>
                <Td right mono>{r.delivered.toLocaleString()}</Td>
                <Td right mono>{r.opened}</Td>
                <Td right mono>{r.clicked}</Td>
                <Td right><Badge variant="green">{r.responded}</Badge></Td>
                <Td right muted>{pct(r.opened, r.delivered)}</Td>
                <Td right><Badge variant="coral">{r.bounced}</Badge></Td>
              </tr>
            ))}
          </tbody>
        </Table>
      </TableWrap>
    </div>
  );
}
