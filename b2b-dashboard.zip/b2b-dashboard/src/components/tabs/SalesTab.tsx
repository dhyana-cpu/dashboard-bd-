"use client";
import { useMemo } from "react";
import { Bar } from "react-chartjs-2";
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Tooltip, Legend } from "chart.js";
import { MetricCard, MetricGrid, SectionTitle, Card, TableWrap, Table, Th, Td, Badge } from "@/components/UI";
import type { SalesRecord } from "@/lib/data";
import styles from "./Tabs.module.css";

ChartJS.register(CategoryScale, LinearScale, BarElement, Tooltip, Legend);

const fmtINR = (n: number) => "₹" + Math.round(n).toLocaleString("en-IN");

export default function SalesTab({ data }: { data: SalesRecord[] }) {
  const totRev = data.reduce((s, d) => s + d.revenue, 0);
  const totOrders = data.length;
  const avgOrder = totOrders > 0 ? totRev / totOrders : 0;
  const maxDay = useMemo(() => {
    const byDate: Record<string, number> = {};
    data.forEach(d => { byDate[d.date] = (byDate[d.date] || 0) + d.revenue; });
    const entries = Object.entries(byDate);
    if (!entries.length) return { date: "-", rev: 0 };
    const max = entries.reduce((a, b) => b[1] > a[1] ? b : a);
    return { date: max[0], rev: max[1] };
  }, [data]);

  const chartData = useMemo(() => {
    const byDate: Record<string, number> = {};
    data.forEach(d => { byDate[d.date] = (byDate[d.date] || 0) + d.revenue; });
    const dates = Object.keys(byDate).sort();
    return {
      labels: dates.map(d => d.slice(5)),
      datasets: [{ label: "Revenue", data: dates.map(d => byDate[d]), backgroundColor: "#6c6af6", borderRadius: 4 }],
    };
  }, [data]);

  const opts = {
    responsive: true, maintainAspectRatio: false,
    plugins: { legend: { display: false }, tooltip: { callbacks: { label: (v: {raw: unknown}) => fmtINR(v.raw as number) } } },
    scales: {
      x: { ticks: { color: "#4f4e58", font: { size: 11 } }, grid: { display: false } },
      y: { ticks: { color: "#4f4e58", font: { size: 11 }, callback: (v: unknown) => "₹" + Math.round(Number(v) / 1000) + "k" }, grid: { color: "rgba(255,255,255,0.04)" } },
    },
  };

  const pocMap = data.reduce((acc, d) => {
    if (!acc[d.poc]) acc[d.poc] = { orders: 0, revenue: 0 };
    acc[d.poc].orders++;
    acc[d.poc].revenue += d.revenue;
    return acc;
  }, {} as Record<string, { orders: number; revenue: number }>);

  return (
    <div>
      <MetricGrid>
        <MetricCard label="Total Revenue"  value={fmtINR(totRev)} accent="accent" />
        <MetricCard label="Orders"         value={totOrders} accent="blue" />
        <MetricCard label="Avg Order Value" value={fmtINR(avgOrder)} accent="green" />
        <MetricCard label="Best Day"       value={maxDay.date.slice(5)} sub={fmtINR(maxDay.rev)} accent="amber" />
      </MetricGrid>

      <SectionTitle>Daily revenue</SectionTitle>
      <Card>
        <div className={styles.chartWrap}>
          <Bar data={chartData} options={opts as never} aria-label="Daily revenue chart" />
        </div>
      </Card>

      <SectionTitle>POC performance</SectionTitle>
      <TableWrap>
        <Table>
          <thead>
            <tr><Th>POC</Th><Th right>Orders</Th><Th right>Revenue</Th><Th right>Avg order</Th></tr>
          </thead>
          <tbody>
            {Object.entries(pocMap).sort((a, b) => b[1].revenue - a[1].revenue).map(([poc, s]) => (
              <tr key={poc}>
                <Td><Badge variant="purple">{poc}</Badge></Td>
                <Td right mono>{s.orders}</Td>
                <Td right mono>{fmtINR(s.revenue)}</Td>
                <Td right muted>{fmtINR(s.revenue / s.orders)}</Td>
              </tr>
            ))}
          </tbody>
        </Table>
      </TableWrap>

      <SectionTitle>All orders</SectionTitle>
      <TableWrap>
        <Table>
          <thead>
            <tr>
              <Th>Ref No.</Th>
              <Th>Date</Th>
              <Th>Client</Th>
              <Th>POC</Th>
              <Th>Type</Th>
              <Th right>Revenue</Th>
            </tr>
          </thead>
          <tbody>
            {data.map(r => (
              <tr key={r.refNo}>
                <Td mono>{r.refNo}</Td>
                <Td mono muted>{r.date}</Td>
                <Td>{r.clientName}</Td>
                <Td><Badge variant="purple">{r.poc}</Badge></Td>
                <Td muted>{r.orderType}</Td>
                <Td right mono>{fmtINR(r.revenue)}</Td>
              </tr>
            ))}
          </tbody>
        </Table>
      </TableWrap>
    </div>
  );
}
