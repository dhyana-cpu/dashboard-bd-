"use client";
import { useMemo } from "react";
import { Bar } from "react-chartjs-2";
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Tooltip, Legend } from "chart.js";
import { MetricCard, MetricGrid, SectionTitle, Card, TableWrap, Table, Th, Td, Badge } from "@/components/UI";
import type { MailRecord, EmailByIndustry } from "@/lib/data";
import styles from "./Tabs.module.css";

ChartJS.register(CategoryScale, LinearScale, BarElement, Tooltip, Legend);

const pct = (a: number, b: number) => (b > 0 ? Math.round((a / b) * 100) + "%" : "0%");

export default function MailsTab({ data, byIndustry }: { data: MailRecord[]; byIndustry: EmailByIndustry[] }) {
  const totDel  = data.reduce((s, d) => s + d.delivered, 0);
  const totOpen = data.reduce((s, d) => s + d.opened, 0);
  const totClick= data.reduce((s, d) => s + d.clicked, 0);
  const totResp = data.reduce((s, d) => s + d.responded, 0);

  const chartData = useMemo(() => ({
    labels: data.map(d => d.date.slice(5)),
    datasets: [
      { label: "Delivered", data: data.map(d => d.delivered), backgroundColor: "#4fa3e8", borderRadius: 4 },
      { label: "Opened",    data: data.map(d => d.opened),    backgroundColor: "#36c98e", borderRadius: 4 },
      { label: "Clicked",   data: data.map(d => d.clicked),   backgroundColor: "#f5a623", borderRadius: 4 },
      { label: "Responded", data: data.map(d => d.responded), backgroundColor: "#f06478", borderRadius: 4 },
    ],
  }), [data]);

  const opts = {
    responsive: true, maintainAspectRatio: false,
    plugins: { legend: { display: false } },
    scales: {
      x: { ticks: { color: "#4f4e58", font: { size: 11 } }, grid: { display: false } },
      y: { ticks: { color: "#4f4e58", font: { size: 11 } }, grid: { color: "rgba(255,255,255,0.04)" } },
    },
  };

  return (
    <div>
      <MetricGrid>
        <MetricCard label="Delivered"  value={totDel.toLocaleString()} accent="blue" />
        <MetricCard label="Opened"     value={totOpen.toLocaleString()} sub={`Rate: ${pct(totOpen, totDel)}`} accent="green" />
        <MetricCard label="Clicked"    value={totClick} sub={`Rate: ${pct(totClick, totDel)}`} accent="amber" />
        <MetricCard label="Responded"  value={totResp}  sub={`Rate: ${pct(totResp, totDel)}`} accent="coral" />
      </MetricGrid>

      <SectionTitle>Daily mail activity</SectionTitle>
      <Card>
        <div className={styles.legendRow} style={{ marginBottom: 16 }}>
          <span className={styles.legendItem}><span className={styles.dot} style={{ background: "#4fa3e8" }} />Delivered</span>
          <span className={styles.legendItem}><span className={styles.dot} style={{ background: "#36c98e" }} />Opened</span>
          <span className={styles.legendItem}><span className={styles.dot} style={{ background: "#f5a623" }} />Clicked</span>
          <span className={styles.legendItem}><span className={styles.dot} style={{ background: "#f06478" }} />Responded</span>
        </div>
        <div className={styles.chartWrap}>
          <Bar data={chartData} options={opts} aria-label="Daily mail activity" />
        </div>
      </Card>

      <SectionTitle>By industry (all time)</SectionTitle>
      <TableWrap>
        <Table>
          <thead>
            <tr>
              <Th>Industry</Th>
              <Th right>Delivered</Th>
              <Th right>Opened</Th>
              <Th right>Open rate</Th>
              <Th right>Clicked</Th>
              <Th right>CTR</Th>
              <Th right>Responded</Th>
              <Th right>Bounced</Th>
            </tr>
          </thead>
          <tbody>
            {byIndustry.map(r => (
              <tr key={r.industry}>
                <Td>{r.industry}</Td>
                <Td right mono>{r.delivered.toLocaleString()}</Td>
                <Td right mono>{r.opened}</Td>
                <Td right muted>{pct(r.opened, r.delivered)}</Td>
                <Td right mono>{r.clicked}</Td>
                <Td right muted>{pct(r.clicked, r.delivered)}</Td>
                <Td right><Badge variant="green">{r.responded}</Badge></Td>
                <Td right><Badge variant="coral">{r.bounced}</Badge></Td>
              </tr>
            ))}
          </tbody>
        </Table>
      </TableWrap>

      <SectionTitle>Daily breakdown</SectionTitle>
      <TableWrap>
        <Table>
          <thead>
            <tr>
              <Th>Date</Th>
              <Th right>Delivered</Th>
              <Th right>Opened</Th>
              <Th right>Open rate</Th>
              <Th right>Clicked</Th>
              <Th right>Responded</Th>
            </tr>
          </thead>
          <tbody>
            {data.map(r => (
              <tr key={r.date}>
                <Td mono>{r.date}</Td>
                <Td right mono>{r.delivered.toLocaleString()}</Td>
                <Td right mono>{r.opened}</Td>
                <Td right muted>{pct(r.opened, r.delivered)}</Td>
                <Td right mono>{r.clicked}</Td>
                <Td right><Badge variant={r.responded > 10 ? "green" : "muted"}>{r.responded}</Badge></Td>
              </tr>
            ))}
          </tbody>
        </Table>
      </TableWrap>
    </div>
  );
}
