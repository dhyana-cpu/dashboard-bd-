import { Empty } from "@/components/UI";

export default function EventsTab() {
  return (
    <div style={{ marginTop: 8 }}>
      <Empty
        message="No events data yet"
        sub="Add event records to your Events sheet and update src/lib/data.ts to see them here."
      />
    </div>
  );
}
