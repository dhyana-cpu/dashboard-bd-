"use client";
import { MetricCard, MetricGrid, SectionTitle, TableWrap, Table, Th, Td, Badge } from "@/components/UI";
import type { InMailRecord } from "@/lib/data";

export default function InMailsTab({ data }: { data: InMailRecord[] }) {
  const fm = data.filter(d => d.industry === "FM").length;
  const it = data.filter(d => d.industry === "IT").length;

  return (
    <div>
      <MetricGrid>
        <MetricCard label="Total InMails"    value={data.length} accent="accent" />
        <MetricCard label="Facility Mgmt"    value={fm} accent="blue" />
        <MetricCard label="IT"               value={it} accent="green" />
      </MetricGrid>

      <SectionTitle>All LinkedIn outreach</SectionTitle>
      <TableWrap>
        <Table>
          <thead>
            <tr>
              <Th>#</Th>
              <Th>Industry</Th>
              <Th>Company</Th>
              <Th>Role</Th>
              <Th>POC</Th>
              <Th>LinkedIn</Th>
            </tr>
          </thead>
          <tbody>
            {data.map(r => (
              <tr key={r.srNo}>
                <Td mono muted>{r.srNo}</Td>
                <Td>
                  <Badge variant={r.industry === "FM" ? "blue" : "green"}>{r.industry}</Badge>
                </Td>
                <Td>{r.companyName}</Td>
                <Td muted>{r.role}</Td>
                <Td>{r.poc}</Td>
                <Td>
                  <a
                    href={r.linkedin}
                    target="_blank"
                    rel="noopener noreferrer"
                    style={{ color: "var(--accent)", fontSize: 12 }}
                  >
                    View profile →
                  </a>
                </Td>
              </tr>
            ))}
          </tbody>
        </Table>
      </TableWrap>
    </div>
  );
}
