"use client";
import { useState, useMemo } from "react";
import styles from "./Dashboard.module.css";
import { mailData, salesData, adsData, inMailData, emailByIndustry } from "@/lib/data";
import MailsTab from "./tabs/MailsTab";
import SalesTab from "./tabs/SalesTab";
import AdsTab from "./tabs/AdsTab";
import InMailsTab from "./tabs/InMailsTab";
import EventsTab from "./tabs/EventsTab";
import OverviewTab from "./tabs/OverviewTab";

const TABS = ["Overview", "Mails", "Sales", "Ads", "InMails", "Events"] as const;
type Tab = (typeof TABS)[number];

function getDefaultDates() {
  const allDates = [
    ...mailData.map(d => d.date),
    ...salesData.map(d => d.date),
    ...adsData.map(d => d.date),
  ].sort();
  return { from: allDates[0] ?? "2026-03-31", to: allDates[allDates.length - 1] ?? "2026-04-13" };
}

export default function Dashboard() {
  const [tab, setTab] = useState<Tab>("Overview");
  const defaults = useMemo(getDefaultDates, []);
  const [dateFrom, setDateFrom] = useState(defaults.from);
  const [dateTo, setDateTo] = useState(defaults.to);

  const filtered = useMemo(() => ({
    mails: mailData.filter(d => d.date >= dateFrom && d.date <= dateTo),
    sales: salesData.filter(d => d.date >= dateFrom && d.date <= dateTo),
    ads: adsData.filter(d => d.date >= dateFrom && d.date <= dateTo),
  }), [dateFrom, dateTo]);

  return (
    <div className={styles.root}>
      <header className={styles.header}>
        <div className={styles.headerLeft}>
          <div className={styles.logo}>
            <span className={styles.logoMark} />
            <span className={styles.logoText}>B2B Dashboard</span>
          </div>
          <nav className={styles.nav}>
            {TABS.map(t => (
              <button
                key={t}
                className={`${styles.navBtn} ${tab === t ? styles.navBtnActive : ""}`}
                onClick={() => setTab(t)}
              >
                {t}
              </button>
            ))}
          </nav>
        </div>
        <div className={styles.dateBar}>
          <label className={styles.dateLabel}>From</label>
          <input
            type="date"
            className={styles.dateInput}
            value={dateFrom}
            onChange={e => setDateFrom(e.target.value)}
          />
          <span className={styles.dateSep}>→</span>
          <input
            type="date"
            className={styles.dateInput}
            value={dateTo}
            onChange={e => setDateTo(e.target.value)}
          />
        </div>
      </header>

      <main className={styles.main}>
        {tab === "Overview"  && <OverviewTab mails={filtered.mails} sales={filtered.sales} ads={filtered.ads} inmails={inMailData} emailByIndustry={emailByIndustry} />}
        {tab === "Mails"     && <MailsTab data={filtered.mails} byIndustry={emailByIndustry} />}
        {tab === "Sales"     && <SalesTab data={filtered.sales} />}
        {tab === "Ads"       && <AdsTab data={filtered.ads} />}
        {tab === "InMails"   && <InMailsTab data={inMailData} />}
        {tab === "Events"    && <EventsTab />}
      </main>
    </div>
  );
}
