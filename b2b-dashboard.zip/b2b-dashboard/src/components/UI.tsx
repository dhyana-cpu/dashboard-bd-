import styles from "./UI.module.css";

export function MetricCard({
  label, value, sub, accent
}: { label: string; value: string | number; sub?: string; accent?: "green" | "amber" | "blue" | "coral" | "accent" }) {
  return (
    <div className={`${styles.metricCard} ${accent ? styles[`accent_${accent}`] : ""}`}>
      <div className={styles.metricLabel}>{label}</div>
      <div className={styles.metricValue}>{value}</div>
      {sub && <div className={styles.metricSub}>{sub}</div>}
    </div>
  );
}

export function MetricGrid({ children }: { children: React.ReactNode }) {
  return <div className={styles.metricGrid}>{children}</div>;
}

export function SectionTitle({ children }: { children: React.ReactNode }) {
  return <div className={styles.sectionTitle}>{children}</div>;
}

export function Card({ children, className }: { children: React.ReactNode; className?: string }) {
  return <div className={`${styles.card} ${className ?? ""}`}>{children}</div>;
}

export function TableWrap({ children }: { children: React.ReactNode }) {
  return (
    <div className={styles.tableWrap}>
      <div className={styles.tableScroll}>{children}</div>
    </div>
  );
}

export function Table({ children }: { children: React.ReactNode }) {
  return <table className={styles.table}>{children}</table>;
}

export function Th({ children, right }: { children: React.ReactNode; right?: boolean }) {
  return <th className={`${styles.th} ${right ? styles.right : ""}`}>{children}</th>;
}

export function Td({ children, right, mono, muted }: { children: React.ReactNode; right?: boolean; mono?: boolean; muted?: boolean }) {
  return (
    <td className={`${styles.td} ${right ? styles.right : ""} ${mono ? styles.mono : ""} ${muted ? styles.muted : ""}`}>
      {children}
    </td>
  );
}

type BadgeVariant = "blue" | "green" | "amber" | "coral" | "purple" | "muted";
export function Badge({ children, variant = "muted" }: { children: React.ReactNode; variant?: BadgeVariant }) {
  return <span className={`${styles.badge} ${styles[`badge_${variant}`]}`}>{children}</span>;
}

export function Empty({ message, sub }: { message: string; sub?: string }) {
  return (
    <div className={styles.empty}>
      <div className={styles.emptyIcon} />
      <p className={styles.emptyMsg}>{message}</p>
      {sub && <p className={styles.emptySub}>{sub}</p>}
    </div>
  );
}
