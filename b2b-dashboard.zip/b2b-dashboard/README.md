# B2B Activity Dashboard

A real-time B2B activity dashboard tracking daily mails, sales, ads, events, and InMails.

## Tech Stack
- **Next.js 14** (App Router)
- **React 18** + TypeScript
- **Chart.js** + react-chartjs-2
- **DM Sans** font

## Getting Started

### 1. Install dependencies
```bash
npm install
```

### 2. Run locally
```bash
npm run dev
```
Open [http://localhost:3000](http://localhost:3000)

### 3. Update your data
All data lives in `src/lib/data.ts`. Edit the arrays there to reflect your latest numbers from Google Sheets.

---

## Deploy to Vercel

### Option A — Vercel CLI (fastest)
```bash
npm install -g vercel
vercel
```
Follow the prompts. Your live URL will be ready in ~30 seconds.

### Option B — GitHub + Vercel (recommended for ongoing updates)
1. Push this folder to a GitHub repo
2. Go to [vercel.com](https://vercel.com) → **Add New Project**
3. Import your GitHub repo
4. Click **Deploy** — no config needed, Vercel auto-detects Next.js

### Option C — Vercel drag & drop
1. Run `npm run build` locally
2. Drag the `.next` folder into [vercel.com/new](https://vercel.com/new)

---

## Keeping Data Fresh

Since data lives in `src/lib/data.ts`, you have two options to keep it live:

**Manual**: Export your Google Sheet as CSV, run the included update script (coming soon), commit & push — Vercel auto-redeploys.

**Automatic**: Connect Google Sheets API in `src/app/api/data/route.ts` and switch the components to fetch from the API route. Happy to help set this up!
